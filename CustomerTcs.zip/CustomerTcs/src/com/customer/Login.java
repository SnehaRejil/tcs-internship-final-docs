package com.customer;



import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.customer.Login;

import com.custom.Utilities;
import com.tcscusto.Basetest;
import com.tcscusto.Othercases;
import com.custom.Utilities;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;


public class Login {
	 WebDriver driver;
	 Basetest objlogin;
	 Othercases blogin;
	@Test
	 
	 public void validations() throws IOException, InterruptedException {

				
			        objlogin=new Basetest(driver);
			        blogin=new Othercases(driver);
					driver.get("https://www.phptravels.net/login" );
					driver.manage().window().maximize();
					String username = Utilities.getCellData(0,0);
					String pwd = Utilities.getCellData(0,1);
					objlogin.logindetails(username,pwd);
					blogin.booking();
					blogin.viewmyvoucher();
					blogin.addfund();
					blogin.adddprofile();
					blogin.updateprofile();
					blogin.logout();
					blogin.invalidligin();
	}		
			
	
	 @BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","F:\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	  

	  @AfterTest
	  public void afterTest() {
		  driver.close();
		}
	  

	}