package com.tcscusto;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Othercases {
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	@FindBy(name="email") 
	private WebElement invalidid;
	@FindBy(name="password") 
	private WebElement invalidpassword;
	@FindBy(xpath="//button[@type=\"submit\"]")  
	private WebElement buttn;
	
	@FindBy(xpath="(//li[@class=\"page-active\"]/following-sibling::li/a)[1]")
	private WebElement Mybookings;
	@FindBy(xpath="(//a[@target=\"_blank\"])[1]")
	private WebElement viewvoucher;
	@FindBy(xpath ="//li[@class=\"user_wallet \"]")
	private WebElement addfund;
	@FindBy(id ="gateway_paypal")
	private WebElement paypal;
	@FindBy(xpath ="//button[@type='submit']")
	private WebElement paynow;
	@FindBy(xpath ="(//li[@class=\"user_wallet \"]/following-sibling::li/a)[1]")
	private WebElement Myprofile;
	@FindBy(name ="address2")
	private WebElement address;
	@FindBy(xpath ="//button[@type='submit']")
	private WebElement updateaddress;
	@FindBy(xpath ="(//li[@class=\"user_wallet \"]/following-sibling::li/a)[2]")
	private WebElement logout;
	public Othercases(WebDriver driver)
	{
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.wait =new WebDriverWait(driver,Duration.ofSeconds(30));
		this.js= (JavascriptExecutor) driver;

	}
	public void invalidligin()throws InterruptedException
	{try {
		invalidid.sendKeys("abc@gmail.com");
		invalidpassword.sendKeys("demouser");
		buttn.click();
		Thread.sleep(2000);
	}catch (Exception e) {
		e.printStackTrace();
	}
	}	
	public void booking()
	{try {
		WebElement book = wait.until(ExpectedConditions.visibilityOf(Mybookings));
		js.executeScript("arguments[0].click();", book);
		Thread.sleep(3000);
	
	}catch (Exception e) {
		// TODO: handle exception
	}}
	
	public void viewmyvoucher() throws InterruptedException
	{try {
		WebElement oview = wait.until(ExpectedConditions.visibilityOf(viewvoucher));
		js.executeScript("arguments[0].click();", oview);
		Thread.sleep(3000);
		//driver.switchTo().window(tabs.get(1));
	
	}catch (Exception e) {
		// TODO: handle exception
	}}


public void addfund() throws InterruptedException
{try {
	

	WebElement ofund=wait.until(ExpectedConditions.visibilityOf(addfund));
	js.executeScript("arguments[0].scrollIntoView;", ofund);
	ofund.click();
	Thread.sleep(3000);
	wait.until(ExpectedConditions.visibilityOf(paypal)).click();
	Thread.sleep(3000);
	wait.until(ExpectedConditions.visibilityOf(paynow)).click();
	//Thread.sleep(2000);
	//driver.navigate().back();
	
}catch (Exception e) {
	e.printStackTrace();// TODO: handle exception
}
}
	
public void adddprofile()
{
	try {		

	wait.until(ExpectedConditions.visibilityOf(Myprofile)).click();
	Thread.sleep(3000);

}catch (Exception e) {
	e.printStackTrace();// TODO: handle exception
}
}

public void updateprofile()
{
	try {		

	wait.until(ExpectedConditions.visibilityOf(address)).clear();
	address.sendKeys("Bangalore");
	Thread.sleep(3000);
	
    WebElement oupdate=	wait.until(ExpectedConditions.visibilityOf(updateaddress));
	js.executeScript("arguments[0].click();", oupdate);

}catch (Exception e) {
	e.printStackTrace();// TODO: handle exception
}
}
public void logout()
{try {
	wait.until(ExpectedConditions.visibilityOf(logout)).click();
}catch (Exception e) {
	// TODO: handle exception
}
}
}
	
	
	

	