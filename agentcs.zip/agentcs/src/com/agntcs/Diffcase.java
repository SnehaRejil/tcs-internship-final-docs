package com.agntcs;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Diffcase{
	
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	
	@FindBy(name="email") 
	private WebElement invalidid;
	@FindBy(name="password") 
	private WebElement invalidpassword;
	@FindBy(xpath="//button[@type=\"submit\"]")  
	private WebElement buttn;
	
	@FindBy(xpath="(//li[@class=\"page-active\"]/following-sibling::li/a)[1]")
	private WebElement bookingbutton;
	@FindBy(xpath = "(//a[@href=\"https://phptravels.net/account/add_funds\"])[2]")
	private WebElement fundbutton;
	@FindBy(xpath ="(//a[@href=\"https://phptravels.net/account/profile\"])[2]")
	private WebElement profilebutton;
    @FindBy(linkText = "Blog")
	private WebElement blogg;
    @FindBy(xpath = "//a[@title='flights']")
	private WebElement flightt;
    @FindBy(xpath = "//div[@class='logo']/a")
	private WebElement homee;
	@FindBy(id = "currency")
	private WebElement currencydropdownusd;
	@FindBy(xpath = "//ul[@class=\"dropdown-menu show\"] /li[7]")
	private WebElement currencydropdownINR;
	@FindBy(linkText = "Hotels")
	private WebElement hotell;
	@FindBy(xpath = "//span[@title=\" Search by City\"]")
	private WebElement cityy;
	@FindBy(id = "checkin")
	private WebElement searchh;
	@FindBy(linkText = "Offers")
	private WebElement offerss;
	@FindBy(linkText = "Tours")
	private WebElement tourss;
    @FindBy(xpath = "//a[@title='visa']")
	private WebElement visaa;
	@FindBy(xpath = "(//a[ @href=\"https://phptravels.net/account/logout\" ])[2]")
	private WebElement logout;

	public Diffcase(WebDriver driver) 
	
	{this.driver=driver;
	PageFactory.initElements(driver, this);
	this.wait =new WebDriverWait(driver,Duration.ofSeconds(30));
	this.js= (JavascriptExecutor) driver;
	
	}
	public void invalidligin()throws InterruptedException
	{try {
		invalidid.sendKeys("abc@gmail.com");
		invalidpassword.sendKeys("demouser");
		buttn.click();
		Thread.sleep(2000);
	}catch (Exception e) {
		e.printStackTrace();
	}
	}	
	
	public void Mybooking()
	{try {
		WebElement book = wait.until(ExpectedConditions.visibilityOf(bookingbutton));
		js.executeScript("arguments[0].click();", book);
		
	}catch (Exception e) {
		e.printStackTrace();
	
	}}
	
	public void Addfund() throws InterruptedException {
		try {

			WebElement ofund = wait.until(ExpectedConditions.visibilityOf(fundbutton));
			js.executeScript("arguments[0].click();", ofund);
			ofund.click();
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}

public void Profile()
{
	try {
WebElement oprofile=	wait.until(ExpectedConditions.visibilityOf(profilebutton));
	js.executeScript("arguments[0].click();", oprofile);
    Thread.sleep(3000);
	
}catch (Exception e) {
	e.printStackTrace();
}	
}
	public void Blog() {
		try {
			WebElement blog = wait.until(ExpectedConditions.visibilityOf(blogg));
			js.executeScript("arguments[0].click();", blog);
            Thread.sleep(2000);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}

public void Click() {
	try {
		WebElement flightbtnclick = wait.until(ExpectedConditions.visibilityOf(flightt));
		js.executeScript("arguments[0].click();", flightbtnclick);
		Thread.sleep(3000);
		
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}
public void Home() {
	try {
		wait.until(ExpectedConditions.visibilityOf(homee)).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(currencydropdownusd)).click();
		Thread.sleep(2000);
		
		WebElement target = wait.until(ExpectedConditions.visibilityOf(currencydropdownINR));

		//act.sendKeys(Keys.chord(Keys.DOWN, Keys.DOWN, Keys.DOWN, Keys.DOWN, Keys.DOWN, Keys.DOWN, Keys.DOWN))
				//.click(target).perform();

		//Thread.sleep(2000);
		
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}

public void Hotel() {
	try {
		WebElement ohotel = wait.until(ExpectedConditions.visibilityOf(hotell));
		js.executeScript("arguments[0].click();", ohotel);

		Thread.sleep(2000);
		
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}

public void Searchhotel() {
	try {
		WebElement City1 = wait.until(ExpectedConditions.visibilityOf(cityy));
		wait.until(ExpectedConditions.elementToBeClickable(cityy));
		js.executeScript("arguments[0].click();", City1);
		City1.sendKeys("Bangalore");
		City1.click();
		wait.until(ExpectedConditions.visibilityOf(searchh)).click();

		Thread.sleep(2000);
		
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}

public void Offers()
{try {
	WebElement offers=wait.until(ExpectedConditions.visibilityOf(offerss));
	js.executeScript("arguments[0].click();", offers);
    Thread.sleep(3000);
	}catch (Exception e) {
	e.printStackTrace();
	
}}

public void Tours()
{try {
    WebElement otour=	wait.until(ExpectedConditions.visibilityOf(tourss));
	js.executeScript("arguments[0].click();", otour);
    Thread.sleep(3000);
	
}catch (Exception e) {
	e.printStackTrace();
	}}
public void Visa()
{try {
	WebElement visabtnclick= wait.until(ExpectedConditions.visibilityOf(visaa));
	js.executeScript("arguments[0].click();", visabtnclick);
    Thread.sleep(2000);
	}catch (Exception e) {
	e.printStackTrace();
	}}
public void logout() {
	try {
		WebElement ologout = wait.until(ExpectedConditions.visibilityOf(logout));
		js.executeScript("arguments[0].click();", ologout);
         Thread.sleep(2000);
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}
}