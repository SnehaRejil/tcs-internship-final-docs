package com.agen;



import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.agen.loginpage;
import com.agge.Excelutility2;

import com.agntcs.Basetest2;
import com.agntcs.Diffcase;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class loginpage {
	 WebDriver driver;
	 Basetest2 objjlogin;
	 Diffcase alogin;
	@Test
	 
	 public void validations() throws IOException, InterruptedException {

				
			        objjlogin=new Basetest2(driver);
			        alogin=new Diffcase(driver);
					driver.get("https://www.phptravels.net/login" );
					driver.manage().window().maximize();
					String username = Excelutility2.getCellData(0,0);
					String pwd = Excelutility2.getCellData(0,1);
					objjlogin.logindetails(username,pwd);
					alogin.Addfund();
					alogin.Blog();
					alogin.Click();
					alogin.Home();
					alogin.Hotel();
					alogin.Mybooking();
					alogin.Offers();
					alogin.Profile();
					alogin.Searchhotel();
					alogin.Tours();
					alogin.Tours();
					alogin.Visa();
					alogin.invalidligin();
					
	}
			
	
	@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","F:\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	  

	  @AfterTest
	  public void afterTest() {
		  driver.close();
		}
	  

	}