package com.admi;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelutility1 {
	FileInputStream ofile;
	XSSFWorkbook oworkbook;
	XSSFSheet osheet;
	XSSFRow orow;
	XSSFCell ocell;
	
	
		
		public static XSSFWorkbook excelwbook;
		public static XSSFSheet excelWsheet;

		public static String getCellData(int RowNum,int ColNum) throws IOException
		{
			FileInputStream Excelfile =new FileInputStream("C:\\Users\\USER\\Desktop\\admintcs.xlsx");
			excelwbook = new XSSFWorkbook(Excelfile);
			excelWsheet = excelwbook.getSheetAt(0);
			return excelWsheet.getRow(RowNum).getCell(ColNum).getStringCellValue();	
		}
	}
