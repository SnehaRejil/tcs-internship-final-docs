package com.admtcs;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Basetest1 {
	WebDriverWait wait;
	 WebDriver driver;
	
	@FindBy(name="email") 
	private WebElement id1;
	@FindBy(name="password") 
	private WebElement password;
	@FindBy(xpath="//button[@type=\"submit\"]")  
	private WebElement button1;
	public Basetest1(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		this.wait =new WebDriverWait(driver, Duration.ofSeconds(30));

	}
	public  void logindetails(String id,String Password)throws InterruptedException
	{
		

	
		wait.until(ExpectedConditions.visibilityOf(id1)).sendKeys(id);
		wait.until(ExpectedConditions.visibilityOf(password)).sendKeys(Password);
		wait.until(ExpectedConditions.visibilityOf(button1)).click();

	
}

}
