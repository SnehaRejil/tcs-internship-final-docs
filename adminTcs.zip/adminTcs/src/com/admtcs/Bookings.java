package com.admtcs;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Bookings {
	
	
		WebDriver driver;
		WebDriverWait wait;
		JavascriptExecutor js;
		
		@FindBy(name="email") 
		private WebElement invalidid;
		@FindBy(name="password") 
		private WebElement invalidpassword;
		@FindBy(xpath="//button[@type=\"submit\"]")  
		private WebElement buttn;
		
		
		@FindBy(xpath="(//a[text()='Bookings'])[1]")
		private WebElement button;
		
		
		@FindBy(xpath="//i[text()='credit_score']")
		private WebElement paidbutton;

		@FindBy(xpath="(//a[@class='btn btn-outline-dark mdc-ripple-upgraded' and @href='https://phptravels.net/api/../hotels/booking/invoice/3215/5']")
		private WebElement invoice;
		
		@FindBy(xpath="//i[text()='clear']")
		private WebElement  deletebutton;
		
		@FindBy(xpath="(//i[@class=\"fa fa-times\"]/parent::button)[1]")
		private WebElement  deletebutton2;

		@FindBy(xpath="//i[text()=\"event\"]")
		private WebElement pendingbooking;
		
		@FindBy(id="booking_status")
		private WebElement status;
		

		@FindBy(xpath="(//div[@class='display-5'])[1]")
		private WebElement count;
		
		@FindBy(xpath="//a[text()='Website']")
		private WebElement site;
		
		public Bookings(WebDriver driver)
		{
			
			this.driver=driver;
			PageFactory.initElements(driver, this);
			this.wait =new WebDriverWait(driver,Duration.ofSeconds(30));
			this.js= (JavascriptExecutor) driver;

		}
		public void invalidligin()throws InterruptedException
		{try {
			invalidid.sendKeys("abc@gmail.com");
			invalidpassword.sendKeys("demouser");
			buttn.click();
			Thread.sleep(2000);
		}catch (Exception e) {
			e.printStackTrace();
		}
		}	
		
		
		
		public void viewbooking()
		{try {
			WebElement book = wait.until(ExpectedConditions.visibilityOf(button));
			js.executeScript("arguments[0].click();", book);
			Thread.sleep(3000);
		    wait.until(ExpectedConditions.visibilityOf(paidbutton)).click();
			Thread.sleep(3000);
		   
		}catch (Exception e) {
			e.printStackTrace();
		}}
			
		public void viewinvoice()	
		{try {
				
			wait.until(ExpectedConditions.visibilityOf(invoice)).click();		
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				Thread.sleep(3000);

				
				}catch (Exception e) {
					e.printStackTrace();
					
				}}
		public void deletebooking()
		{try {
			WebElement book = wait.until(ExpectedConditions.visibilityOf(deletebutton));
			js.executeScript("arguments[0].click();", book);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(deletebutton2)).click();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			Thread.sleep(3000);

			}catch (Exception e) {
			e.printStackTrace();
			
		}}
		
		public void statusupdate()
		{try {
			
		String initialcounter=wait.until(ExpectedConditions.visibilityOf(count)).getText();
        System.out.println("value of the counter before click/refresh is : " + initialcounter);
           WebElement obook = wait.until(ExpectedConditions.visibilityOf(pendingbooking));
			js.executeScript("arguments[0].click();", obook);
			Thread.sleep(3000);
			 WebElement bookst=wait.until(ExpectedConditions.visibilityOf(status));
            Select oselect = new Select(bookst);
			Thread.sleep(4000);
          oselect.selectByIndex(1);
			Thread.sleep(3000);
			String aftercounter=wait.until(ExpectedConditions.visibilityOf(count)).getAttribute("value");
			System.out.println("value of the counter before click/refresh is : " + aftercounter);
			
			}catch (Exception e) {
			e.printStackTrace();
		
		}}
		public void pendingbooking()
		{try {
			WebElement books = wait.until(ExpectedConditions.visibilityOf(count));
			js.executeScript("arguments[0].click();", books);
			Thread.sleep(3000);
           }catch (Exception e) {
			e.printStackTrace();
			
		
		}
	}
	public void  clickwebsite() throws InterruptedException
	{try {
		wait.until(ExpectedConditions.visibilityOf(site)).click();		
		Thread.sleep(2000);
		
	}
	catch (Exception e) {
		e.printStackTrace();
		
	
	}
	}

}
