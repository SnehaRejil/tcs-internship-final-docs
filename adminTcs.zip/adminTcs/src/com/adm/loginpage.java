package com.adm;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import com.adm.loginpage;
import com.admtcs.Basetest1;
import com.admtcs.Bookings;
import com.admi.Excelutility1;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;


public class loginpage {
	 WebDriver driver;
	 Basetest1 objlogin;
	 Bookings oologin;
	@Test
	 
	 public void validations() throws IOException, InterruptedException {

				
			        objlogin=new Basetest1(driver);
			        oologin=new Bookings(driver);
					driver.get("https://phptravels.net/api/admin" );
					driver.manage().window().maximize();
					String username = Excelutility1.getCellData(0,0);
					String pwd = Excelutility1.getCellData(0,1);
					objlogin.logindetails(username,pwd);
		            oologin.viewbooking();
		            oologin.viewinvoice();
					oologin.deletebooking();
					oologin.statusupdate();
					oologin.pendingbooking();
					oologin.clickwebsite();
					oologin.invalidligin();
					
					
	}		
			
		@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","F:\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	  

	  @AfterTest
	  public void afterTest() {
		  driver.close();
		}
	  

	}