package com.supplie;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import com.supplie.loginpage;
import com.suptcs.Basetest;
import com.suptcs.othertestcas;
import com.supp.Excelutility;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginpage {
	 WebDriver driver;
	 Basetest objlogin;
	 othertestcas elogin;
	@Test
	 
	 public void validations() throws IOException, InterruptedException {

				
			        objlogin=new Basetest(driver);
			        elogin=new othertestcas(driver);
					
			        driver.get("https://www.phptravels.net/supplier" );
					driver.manage().window().maximize();
					
					String username = Excelutility.getCellData(0,0);
					String pwd = Excelutility.getCellData(0,1);
					objlogin.logindetails(username,pwd);
					elogin.view1();
					elogin.view2();
					elogin.booking();
				    elogin.setbooking();
			    	elogin.Clicktours();
			    	elogin.invalidligin();
	}
	  @BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","F:\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	  

	  @AfterTest
	  public void afterTest() {
		  driver.close();
		}
	  

	}