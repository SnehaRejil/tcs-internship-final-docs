package com.suptcs;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class othertestcas {
	WebDriverWait wait;
	 WebDriver driver;
	 JavascriptExecutor js;
	     
	       @FindBy(name="email") 
		   private WebElement invalidid;
		   @FindBy(name="password") 
		   private WebElement invalidpassword;
		   @FindBy(xpath="//button[@type=\"submit\"]")  
		   private WebElement buttn;
		
	       @FindBy(xpath="//div[text()='Sales overview & summary']")
			private WebElement dashboard1;
			
			@FindBy(xpath= "//h2 [text()='Revenue Breakdown 2023']")
			private WebElement dashboard2;

			@FindBy(linkText="style=")
			private WebElement pendingbotton;
			
            @FindBy(id="booking_status")
			private WebElement bookstatus;

			@FindBy(linkText ="Bookings")
			private WebElement bookingbutton;

			@FindBy(xpath = "//a[@aria-controls='toursmodule']")
			private WebElement toursbutton;
		
		
			public othertestcas(WebDriver driver)
			{
				
				this.driver=driver;
				PageFactory.initElements(driver, this);
				this.wait =new WebDriverWait(driver,Duration.ofSeconds(30));
				this.js= (JavascriptExecutor) driver;

			}
			
			
			public void invalidligin()throws InterruptedException
			{try {
				invalidid.sendKeys("abc@gmail.com");
				invalidpassword.sendKeys("demouser");
				buttn.click();
				Thread.sleep(2000);
			}catch (Exception e) {
				e.printStackTrace();
			}
			}		
			
			public void view1()
			{try {
				String text =wait.until(ExpectedConditions.visibilityOf(dashboard1)).getText();
				System.out.println(text);
				
			}catch (Exception e) {
				e.printStackTrace();	
			}}
			public void view2()
			{try {
				String text2 =wait.until(ExpectedConditions.visibilityOf(dashboard2)).getText();
				System.out.println(text2);
				
			}catch (Exception e) {
				e.printStackTrace();	
			}	
			}
		
			public void setbooking()
			{try {
				WebElement book = wait.until(ExpectedConditions.visibilityOf(pendingbotton));
				js.executeScript("arguments[0].click();", book);
				Thread.sleep(3000);

				wait.until(ExpectedConditions.visibilityOf(bookstatus)).click();
				Thread.sleep(6000);

				Select oselect = new Select(wait.until(ExpectedConditions.visibilityOf(bookstatus)));
				Thread.sleep(6000);

				oselect.selectByVisibleText("Confirmed");
				Thread.sleep(6000);

			
			}catch (Exception e) {
				e.printStackTrace();	
			}}
			public void booking()
			{try {
				WebElement books = wait.until(ExpectedConditions.visibilityOf(bookingbutton));
				js.executeScript("arguments[0].click();", books);
				Thread.sleep(6000);

			}catch (Exception e) {
				e.printStackTrace();
				}
			}
		
		
			public void Clicktours()
			{try {
				
				WebElement otour = wait.until(ExpectedConditions.visibilityOf(toursbutton));
				js.executeScript("arguments[0].click();", otour);
			
				Thread.sleep(6000);
				
			}catch (Exception e) {
				e.printStackTrace();
				
			}}
		}
	
		


